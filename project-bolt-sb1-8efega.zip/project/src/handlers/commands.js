import db from '../database/store.js';

export const handleStart = (bot, msg, startParam) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const username = msg.from.username;

  // Register user
  db.insertUser(userId, username);
  db.insertVerification(userId);

  // Check if user came from referral
  if (startParam && startParam !== userId) {
    db.insertReferral(startParam, userId);
  }

  const keyboard = {
    inline_keyboard: [
      [{ text: '🔗 Get Referral Link', callback_data: 'referral_link' }],
      [{ text: '💰 Check Balance', callback_data: 'balance' }],
      [{ text: '📊 My Referrals', callback_data: 'referrals' }],
      [{ text: '✅ Verify Account', callback_data: 'verify_group' }]
    ]
  };

  bot.sendMessage(chatId,
    '🚀 Welcome to the Referral Bot!\n\n' +
    '1️⃣ Join our group\n' +
    '2️⃣ Complete verification\n' +
    '3️⃣ Start earning points!\n\n' +
    '💡 Earn 50 points for each verified referral!',
    { reply_markup: keyboard }
  );
};

export const handleReferralLink = (bot, msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const botUsername = bot.options.username;
  
  const referralLink = `https://t.me/${botUsername}?start=${userId}`;
  
  bot.sendMessage(chatId,
    '🔗 Here\'s your unique referral link:\n\n' +
    `${referralLink}\n\n` +
    '📱 Share this link with your friends!\n' +
    '💰 Earn 50 points for each verified referral!'
  );
};

export const handleReferrals = (bot, msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  const referrals = db.getReferrals(userId);
  const completed = referrals.filter(r => r.status === 'completed').length;
  const pending = referrals.filter(r => r.status === 'pending').length;
  
  bot.sendMessage(chatId,
    '📊 Your Referral Statistics:\n\n' +
    `✅ Completed Referrals: ${completed}\n` +
    `⏳ Pending Referrals: ${pending}\n` +
    `💰 Total Points Earned: ${completed * 50}`
  );
};

export const handleBalance = (bot, msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  const user = db.getUser(userId);
  
  bot.sendMessage(chatId,
    '💰 Your Balance:\n\n' +
    `Current Points: ${user?.points || 0}\n\n` +
    '📝 Earn more points by:\n' +
    '• Referring new users (50 points)\n' +
    '• Completing tasks (varies)'
  );
};

export const handleAdmin = async (bot, msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  const user = db.getUser(userId);
  
  if (!user?.is_admin) {
    bot.sendMessage(chatId, '❌ This command is only available to administrators.');
    return;
  }
  
  const topReferrers = db.getTopReferrers();
  let message = '📊 Top Referrers:\n\n';
  
  topReferrers.forEach((user, index) => {
    message += `${index + 1}. @${user.username}\n` +
               `   Referrals: ${user.total_referrals}\n` +
               `   Points: ${user.points}\n\n`;
  });
  
  bot.sendMessage(chatId, message);
};