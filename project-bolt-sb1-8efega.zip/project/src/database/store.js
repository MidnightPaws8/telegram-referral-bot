// In-memory data store
const store = {
  users: new Map(),
  referrals: new Map(),
  verifications: new Map()
};

export const db = {
  insertUser: (telegramId, username) => {
    if (!store.users.has(telegramId)) {
      store.users.set(telegramId, {
        telegram_id: telegramId,
        username,
        join_date: new Date(),
        points: 0,
        is_admin: false
      });
    }
  },

  getUser: (telegramId) => {
    return store.users.get(telegramId);
  },

  updatePoints: (telegramId, points) => {
    const user = store.users.get(telegramId);
    if (user) {
      user.points += points;
      store.users.set(telegramId, user);
    }
  },

  insertReferral: (referrerId, referredId) => {
    const id = `${referrerId}-${referredId}`;
    if (!store.referrals.has(id)) {
      store.referrals.set(id, {
        referrer_id: referrerId,
        referred_id: referredId,
        status: 'pending',
        created_at: new Date(),
        completed_at: null
      });
    }
  },

  getReferrals: (referrerId) => {
    return Array.from(store.referrals.values())
      .filter(ref => ref.referrer_id === referrerId);
  },

  updateReferralStatus: (status, referrerId, referredId) => {
    const id = `${referrerId}-${referredId}`;
    const referral = store.referrals.get(id);
    if (referral) {
      referral.status = status;
      referral.completed_at = new Date();
      store.referrals.set(id, referral);
    }
  },

  getTopReferrers: () => {
    const referrerStats = new Map();
    
    store.referrals.forEach(ref => {
      if (ref.status === 'completed') {
        const stats = referrerStats.get(ref.referrer_id) || { 
          username: store.users.get(ref.referrer_id)?.username,
          points: store.users.get(ref.referrer_id)?.points || 0,
          total_referrals: 0
        };
        stats.total_referrals++;
        referrerStats.set(ref.referrer_id, stats);
      }
    });

    return Array.from(referrerStats.values())
      .sort((a, b) => b.total_referrals - a.total_referrals)
      .slice(0, 10);
  },

  insertVerification: (telegramId) => {
    if (!store.verifications.has(telegramId)) {
      store.verifications.set(telegramId, {
        telegram_id: telegramId,
        group_joined: false,
        task_completed: false,
        verified_at: null
      });
    }
  },

  updateVerification: (groupJoined, taskCompleted, g, t, telegramId) => {
    const verification = store.verifications.get(telegramId);
    if (verification) {
      verification.group_joined = groupJoined;
      verification.task_completed = taskCompleted;
      verification.verified_at = groupJoined && taskCompleted ? new Date() : null;
      store.verifications.set(telegramId, verification);
    }
  }
};

export default db;