import Database from 'better-sqlite3';

const db = new Database('bot.db');

// Initialize database tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    telegram_id TEXT PRIMARY KEY,
    username TEXT,
    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    points INTEGER DEFAULT 0,
    is_admin BOOLEAN DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS referrals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    referrer_id TEXT,
    referred_id TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY (referrer_id) REFERENCES users(telegram_id),
    FOREIGN KEY (referred_id) REFERENCES users(telegram_id)
  );

  CREATE TABLE IF NOT EXISTS verifications (
    telegram_id TEXT PRIMARY KEY,
    group_joined BOOLEAN DEFAULT 0,
    task_completed BOOLEAN DEFAULT 0,
    verified_at DATETIME,
    FOREIGN KEY (telegram_id) REFERENCES users(telegram_id)
  );
`);

// Prepare statements for better performance
const statements = {
  insertUser: db.prepare('INSERT OR IGNORE INTO users (telegram_id, username) VALUES (?, ?)'),
  getUser: db.prepare('SELECT * FROM users WHERE telegram_id = ?'),
  updatePoints: db.prepare('UPDATE users SET points = points + ? WHERE telegram_id = ?'),
  insertReferral: db.prepare('INSERT INTO referrals (referrer_id, referred_id) VALUES (?, ?)'),
  getReferrals: db.prepare('SELECT * FROM referrals WHERE referrer_id = ?'),
  updateReferralStatus: db.prepare(`
    UPDATE referrals 
    SET status = ?, completed_at = CURRENT_TIMESTAMP 
    WHERE referrer_id = ? AND referred_id = ?
  `),
  getTopReferrers: db.prepare(`
    SELECT u.username, u.points, COUNT(r.id) as total_referrals 
    FROM users u 
    LEFT JOIN referrals r ON u.telegram_id = r.referrer_id 
    WHERE r.status = 'completed' 
    GROUP BY u.telegram_id 
    ORDER BY total_referrals DESC 
    LIMIT 10
  `),
  insertVerification: db.prepare('INSERT OR IGNORE INTO verifications (telegram_id) VALUES (?)'),
  updateVerification: db.prepare(`
    UPDATE verifications 
    SET group_joined = ?, task_completed = ?,
    verified_at = CASE WHEN ? = 1 AND ? = 1 THEN CURRENT_TIMESTAMP ELSE NULL END
    WHERE telegram_id = ?
  `)
};

export default {
  ...statements,
  db
};