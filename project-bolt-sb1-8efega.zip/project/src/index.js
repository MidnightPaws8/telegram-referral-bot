import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
import express from 'express';
import db from './database/store.js';
import { handleStart, handleReferralLink, handleReferrals, handleBalance, handleAdmin } from './handlers/commands.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Keep the server alive
app.get('/', (req, res) => {
  res.send('Bot is running!');
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Initialize bot with webhook in production, polling in development
const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, {
  webHook: process.env.NODE_ENV === 'production'
});

if (process.env.NODE_ENV === 'production') {
  // Set webhook for production
  const url = process.env.APP_URL || 'https://your-app-url.herokuapp.com';
  bot.setWebHook(`${url}/webhook/${process.env.TELEGRAM_BOT_TOKEN}`);
  
  // Handle webhook endpoint
  app.post(`/webhook/${process.env.TELEGRAM_BOT_TOKEN}`, (req, res) => {
    bot.handleUpdate(req.body);
    res.sendStatus(200);
  });
} else {
  // Use polling for development
  bot.startPolling();
}

// Command handlers
bot.onText(/\/start(?:\s+(\w+))?/, (msg, match) => handleStart(bot, msg, match?.[1]));
bot.onText(/\/referral_link/, (msg) => handleReferralLink(bot, msg));
bot.onText(/\/referrals/, (msg) => handleReferrals(bot, msg));
bot.onText(/\/balance/, (msg) => handleBalance(bot, msg));
bot.onText(/\/admin/, (msg) => handleAdmin(bot, msg));

// Handle callback queries from inline keyboard buttons
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data === 'verify_group') {
    // Check if user joined the group
    try {
      const member = await bot.getChatMember(process.env.GROUP_ID, query.from.id);
      if (['member', 'administrator', 'creator'].includes(member.status)) {
        db.updateVerification(true, false, true, false, query.from.id.toString());
        bot.answerCallbackQuery(query.id, { text: '✅ Group join verified!' });
        bot.sendMessage(chatId, 'Great! Now complete one more task to finish verification.');
      } else {
        bot.answerCallbackQuery(query.id, { 
          text: '❌ Please join our group first!',
          show_alert: true 
        });
      }
    } catch (error) {
      console.error('Error checking group membership:', error);
      bot.answerCallbackQuery(query.id, { 
        text: '❌ Error verifying group membership',
        show_alert: true 
      });
    }
  }

  if (data === 'verify_task') {
    // Verify task completion (simplified for demo)
    db.updateVerification(true, true, true, true, query.from.id.toString());
    const verification = db.getUser(query.from.id.toString());
    
    if (verification) {
      // Complete referral if exists
      const referrals = db.getReferrals(query.from.id.toString());
      const pendingReferral = referrals.find(r => r.status === 'pending');
      
      if (pendingReferral) {
        db.updateReferralStatus('completed', pendingReferral.referrer_id, query.from.id.toString());
        db.updatePoints(pendingReferral.referrer_id, 50);
        
        // Notify referrer
        bot.sendMessage(pendingReferral.referrer_id, 
          '🎉 Congratulations! Your referral was successful!\n' +
          'You earned 50 points!'
        );
      }
      
      bot.answerCallbackQuery(query.id, { text: '✅ Verification completed!' });
      bot.sendMessage(chatId, 
        '🎉 Congratulations! You are now fully verified!\n' +
        'Use /referral_link to get your referral link and start earning points!'
      );
    }
  }
});

// Keep the process alive
process.on('SIGINT', () => {
  console.log('Bot is shutting down...');
  process.exit(0);
});

process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
});

console.log('Bot is running...');