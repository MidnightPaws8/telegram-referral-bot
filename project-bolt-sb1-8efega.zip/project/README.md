# Telegram Referral Bot

A Telegram bot that manages referrals and rewards users with points.

## Features

- Unique referral link generation
- Points system for successful referrals
- User verification system
- Admin dashboard
- Real-time referral tracking

## Setup

1. Create a `.env` file from `.env.example`
2. Add your Telegram bot token
3. Set your group ID
4. Deploy to Railway

## Deployment

1. Connect your GitHub repository to Railway
2. Add environment variables in Railway dashboard
3. Deploy automatically from main branch